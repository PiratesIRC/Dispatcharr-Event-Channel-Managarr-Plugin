=========================
Event Channel Managarr
=========================

A Dispatcharr plugin that automatically manages channel visibility based on EPG data and channel names. It is designed to hide channels that currently have no event information and show channels that do.

GitHub Repository: https://github.com/PiratesIRC/Dispatcharr-Event-Channel-Managarr-Plugin